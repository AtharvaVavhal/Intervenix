import { useState, useEffect } from "react";
import Button from "./UI/Button";

export default function Nav() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", fn);
    return () => window.removeEventListener("scroll", fn);
  }, []);

  return (
    <nav
      style={{
        position: "fixed",
        width: "100%",
        padding: "1rem 2rem",
        background: scrolled ? "rgba(0,0,0,0.8)" : "transparent",
      }}
    >
      <Button primary>Request Access</Button>
    </nav>
  );
}