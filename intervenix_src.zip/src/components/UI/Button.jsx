import { useState } from "react";

export default function Button({ children, primary = false }) {
  const [hover, setHover] = useState(false);

  return (
    <button
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        fontFamily: "Inter, sans-serif",
        fontSize: "0.78rem",
        padding: "0.95rem 2rem",
        borderRadius: "3px",
        cursor: "pointer",
        transition: "all 0.25s ease",
        transform: hover ? "translateY(-2px)" : "translateY(0)",

        ...(primary
          ? {
              background: hover ? "#5470ff" : "#3D5AFE",
              color: "#fff",
              border: "none",
              boxShadow: hover
                ? "0 0 30px rgba(61,90,254,0.35)"
                : "0 0 15px rgba(61,90,254,0.15)",
            }
          : {
              background: "transparent",
              color: hover ? "#fff" : "#888",
              border: "1px solid rgba(255,255,255,0.1)",
            }),
      }}
    >
      {children}
    </button>
  );
}