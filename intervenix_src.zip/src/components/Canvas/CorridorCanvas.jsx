import { useEffect, useRef } from "react";

export default function CorridorCanvas({ mousePos = { x: 0.5, y: 0.5 } }) {
  const canvasRef = useRef(null);
  const animationRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");

    let width = window.innerWidth;
    let height = window.innerHeight;

    canvas.width = width;
    canvas.height = height;

    // ✅ resize handling (you didn’t have this properly)
    const handleResize = () => {
      width = window.innerWidth;
      height = window.innerHeight;
      canvas.width = width;
      canvas.height = height;
    };

    window.addEventListener("resize", handleResize);

    let time = 0;

    const render = () => {
      ctx.clearRect(0, 0, width, height);

      const centerX = width / 2;
      const centerY = height * 0.45;

      const lines = 30;

      for (let i = 0; i < lines; i++) {
        const t = i / lines;

        const offset =
          Math.sin(time * 0.001 + i * 0.3) * 20 +
          (mousePos.x - 0.5) * 100;

        const x1 = centerX - (300 + i * 20) + offset;
        const x2 = centerX + (300 + i * 20) + offset;
        const y = centerY + i * 15;

        ctx.strokeStyle = `rgba(61,90,254,${0.05 + t * 0.2})`;
        ctx.lineWidth = 1;

        ctx.beginPath();
        ctx.moveTo(x1, y);
        ctx.lineTo(x2, y);
        ctx.stroke();
      }

      time++;
      animationRef.current = requestAnimationFrame(render);
    };

    render();

    // ✅ CLEANUP (you were missing this → memory leak risk)
    return () => {
      cancelAnimationFrame(animationRef.current);
      window.removeEventListener("resize", handleResize);
    };
  }, [mousePos]);

  return (
    <canvas
      ref={canvasRef}
      style={{
        width: "100%",
        height: "100%",
        display: "block",
      }}
    />
  );
}