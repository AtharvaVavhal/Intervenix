import { useEffect, useState, useRef } from "react";
import CorridorCanvas from "./Canvas/CorridorCanvas";
import Button from "./UI/Button";

export default function Hero({ T }) {
  const [scrollY, setScrollY] = useState(0);
  const heroRef = useRef(null);

  // Parallax (clean)
  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY);
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Mouse tracking (clean)
  const [mousePos, setMousePos] = useState({ x: 0.5, y: 0.5 });

  useEffect(() => {
    const el = heroRef.current;
    if (!el) return;

    const move = (e) => {
      const rect = el.getBoundingClientRect();
      setMousePos({
        x: (e.clientX - rect.left) / rect.width,
        y: (e.clientY - rect.top) / rect.height,
      });
    };

    el.addEventListener("mousemove", move);
    return () => el.removeEventListener("mousemove", move);
  }, []);

  return (
    <section
      ref={heroRef}
      style={{
        position: "relative",
        minHeight: "100vh",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        background: T.bg,
        overflow: "hidden",
        padding: "0 2rem",
        textAlign: "center",
      }}
    >
      {/* Canvas background */}
      <div style={{ position: "absolute", inset: 0, zIndex: 0 }}>
        <CorridorCanvas mousePos={mousePos} />
      </div>

      {/* Content */}
      <div
        style={{
          position: "relative",
          zIndex: 5,
          maxWidth: "860px",
          transform: `translateY(${scrollY * -0.12}px)`,
        }}
      >
        <h1
          style={{
            fontFamily: T.serif,
            fontSize: "clamp(3.5rem, 10vw, 7rem)",
            fontWeight: 700,
            lineHeight: 0.95,
            letterSpacing: "-0.035em",
            color: T.textPrimary,
            marginBottom: "2rem",
          }}
        >
          engineered for<br />
          <em
            style={{
              fontStyle: "italic",
              color: "rgba(239,239,239,0.28)",
            }}
          >
            intelligent{" "}
          </em>
          intervention
        </h1>

        <p
          style={{
            fontFamily: T.sans,
            fontSize: "0.95rem",
            color: T.textSecondary,
            lineHeight: 1.8,
            maxWidth: "420px",
            margin: "0 auto 3rem",
          }}
        >
          Real-time risk signals. Autonomous decision layers.
          Built for institutions that cannot afford to be wrong.
        </p>

        <div style={{ display: "flex", gap: "1rem", justifyContent: "center" }}>
          <Button T={T} primary>Get Early Access</Button>
          <Button T={T}>See How It Works</Button>
        </div>
      </div>

      {/* Bottom fade */}
      <div
        style={{
          position: "absolute",
          bottom: 0,
          left: 0,
          right: 0,
          height: "200px",
          background: `linear-gradient(to bottom, transparent, ${T.bg})`,
          zIndex: 2,
        }}
      />
    </section>
  );
}